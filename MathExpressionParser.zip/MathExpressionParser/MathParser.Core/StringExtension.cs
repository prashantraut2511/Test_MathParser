﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Parser.Core
{
    public static class StringExtension
    {
        /// <summary>
        /// Extenssion method to Check if expression contains any bracket
        /// @Prashant
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static bool ExpressionContainsClosingBrackets(this string expression)
        {
            return !expression.IsNullOrWhiteSpace() && expression.Contains('f');
        }

        public static string GetSubExpression(this string expression)
        {
            if (expression.LastIndexOf('e') < 0 || expression.IndexOf('f') < 3)
                throw new Exception("Invalid format");
            return expression.Substring(expression.LastIndexOf('e'),
                expression.IndexOf('f') - expression.LastIndexOf('e') + 1);
        }
        /// <summary>
        /// Extension method to check if string contains any whitespace or is null
        /// @Prashant
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public static bool IsNullOrWhiteSpace(this string expression)
        {
            if (expression != null)
            {
                foreach (char c in expression)
                {
                    if (Char.IsWhiteSpace(c) == false)
                        return false;
                }
            }
            return true;
        }
    }
}
