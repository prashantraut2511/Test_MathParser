﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Parser.Core
{
    public interface IParseExpression
    {
        int CalculateResult(string expression);
    }
}
