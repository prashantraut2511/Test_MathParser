﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Parser.Core
{
    public class ParseExpression : IParseExpression
    {
        /// <summary>
        /// Evaluate expression result by parsing the string
        /// @Author :Prashant
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        public int CalculateResult(string expression)
        {

            var numbers = ExtractNumbers(expression);
            var operators = ExtractOperators(expression);
            var result = CalculateExpression(numbers, operators);
            return result;
        }

        /// <summary>
        /// Calculate the expression result
        /// @Author :Prashant
        /// </summary>
        /// <param name="numbers"></param>
        /// <param name="operators"></param>
        /// <returns></returns>
       private int CalculateExpression(IList<int> numbers, IList<char> operators)
        {
            var result = numbers[0];
            for (var i = 1; i < numbers.Count; i++)
            {
                var operation = operators[i - 1];
                var nextNumber = numbers[i];
                switch (operation)
                {
                    case 'a':
                        result += nextNumber;
                        break;
                    case 'b':
                        result -= nextNumber;
                        break;
                    case 'c':
                        result *= nextNumber;
                        break;
                    case 'd':
                        result /= nextNumber;
                        break;
                }
            }
            return result;
        }
        /// <summary>
        /// Split string to retrieve result numbers
        /// @Author :Prashant
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        private int[] ExtractNumbers(string expression)
        {
            var splitResult = expression.Split('a', 'b', 'c', 'd');
            var resultNumbers = new int[splitResult.Length];
            for (var i = 0; i < splitResult.Length; i++)
            {
                resultNumbers[i] = int.Parse(splitResult[i]);

            }
            return resultNumbers;
        }

        /// <summary>
        /// Get the operator array. This is hard coded and can be made dynamic depending on requirement
        /// @Author :Prashant
        /// </summary>
        /// <param name="expression"></param>
        /// <returns></returns>
        private char[] ExtractOperators(string expression)
        {
            const string operatorCharacters = "abcd";
            return expression.Where(c => operatorCharacters.Contains(c)).ToArray();
        }
    }
}
