﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Parser.Core;

namespace ParseExpressionTest
{
    [TestClass]
    public class ParseExpressionUnitTest
    {
        /// <summary>
        /// Test the Acceptance criteria. The acceptance criteria can be looped through for each expression.
        /// @Author :Prashant
        /// </summary>
        [TestMethod]
        public void ParseExpression()
        {
            //Acceptance Criteria
            //Input: 3a2c4
            //Result: 20

            //Input: 32a2d2
            //Result: 17

            //Input: 500a10b66c32
            //Result: 14208

            //Input: 3ae4c66fb32
            //Result: 235

            //Input: 3c4d2aee2a4c41fc4f
            //Result: 990

            IParseExpression parseExpression = new ParseExpression();
            var expression = "3c4d2aee2a4c41fc4f";
            int result;
            while (expression.ExpressionContainsClosingBrackets())
            {
                var subExpression = expression.GetSubExpression();
                result = parseExpression.CalculateResult(subExpression.Substring(1, subExpression.Length - 2));
                expression = expression.Replace(subExpression, result.ToString());
            }
            result = parseExpression.CalculateResult(expression);
            Assert.AreEqual(990, result);

        }
    }
}
