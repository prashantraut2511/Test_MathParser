﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using Parser.Core;

namespace MathExpressionParser
{
    public partial class frmParseExpression : Form
    {
        public frmParseExpression()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Acceptance Criteria
            //Input: 3a2c4
            //Result: 20

            //Input: 32a2d2
            //Result: 17

            //Input: 500a10b66c32
            //Result: 14208

            //Input: 3ae4c66fb32
            //Result: 235

            //Input: 3c4d2aee2a4c41fc4f
            //Result: 990

        /// @Author :Prashant
        /// </summary>
        /// <param name="sender"></param>
        /// <param name="e"></param>
        private void btnParseExpression_Click(object sender, EventArgs e)
        {
            try
            {

                int result;
                var expression = txtExpression.Text;

                if (expression.IsNullOrWhiteSpace())
                {
                    MessageBox.Show("Please enter valid expression");
                    return;
                }
                IParseExpression parseExpression = new ParseExpression();

                while (expression.ExpressionContainsClosingBrackets())
                {
                    var subExpression = expression.GetSubExpression();
                    result = parseExpression.CalculateResult(subExpression.Substring(1, subExpression.Length - 2));
                    expression = expression.Replace(subExpression, result.ToString());
                }
                result = parseExpression.CalculateResult(expression);
                lblResult.Text = "Result : " + result.ToString();
                txtExpression.Focus();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Result:" + ex.Message);
            }
        }
    }
}
